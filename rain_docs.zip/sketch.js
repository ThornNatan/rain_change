let cloud = '🌧️';
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220); 
  textSize (100)
  text(cloud,150,225)
} 
function mouseClicked(){
    if (cloud === '🌧️') {
      cloud = '⛈️'; 
      
    } else {
      cloud = '🌧️'; 
    }
}